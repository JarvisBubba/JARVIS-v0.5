/* J.A.R.V.I.S. ACADEMICS — ELA cards */
window.JARVIS=window.JARVIS||{};JARVIS.academics=JARVIS.academics||{};
JARVIS.academics.ela=(function(){const cards={metaphor:'A metaphor compares unlike things directly without using like or as.',simile:'A simile compares unlike things using like or as.',thesis:'A thesis states the central claim or position of an essay.'};return {answer:q=>cards[String(q||'').toLowerCase().trim()]||null};})();
