/* J.A.R.V.I.S. ACADEMICS — history/civics cards */
window.JARVIS=window.JARVIS||{};JARVIS.academics=JARVIS.academics||{};
JARVIS.academics.history=(function(){const cards={federalism:'Federalism divides governmental powers between a central government and regional governments.',democracy:'A democracy is a system in which political power is exercised by the people.',constitution:'A constitution establishes the fundamental structure and powers of a government.'};return {answer:q=>cards[String(q||'').toLowerCase().trim()]||null};})();
