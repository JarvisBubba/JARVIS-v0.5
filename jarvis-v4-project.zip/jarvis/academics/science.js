/* J.A.R.V.I.S. ACADEMICS — science knowledge cards */
window.JARVIS=window.JARVIS||{};JARVIS.academics=JARVIS.academics||{};
JARVIS.academics.science=(function(){const cards={gravity:'Gravity is the attraction between masses.',photosynthesis:'Photosynthesis converts light energy into chemical energy stored in glucose.',atom:'An atom is the basic unit of an element, with a nucleus and electrons.'};return {answer:q=>cards[String(q||'').toLowerCase().trim()]||null};})();
