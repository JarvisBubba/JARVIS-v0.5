/* J.A.R.V.I.S. ADMIN — diagnostics */
window.JARVIS=window.JARVIS||{};JARVIS.admin=JARVIS.admin||{};
JARVIS.admin.diagnostics=function(){return {core:!!JARVIS.core,math:!!JARVIS.math,academics:!!JARVIS.academics,tools:!!JARVIS.tools,admin:!!JARVIS.admin,storage:typeof localStorage!=='undefined',network:navigator.onLine}};
