/* J.A.R.V.I.S. ADMIN — security state */
window.JARVIS=window.JARVIS||{};JARVIS.admin=JARVIS.admin||{};
JARVIS.admin.security=(function(){const K='jarvis-v4-access-locked';return {locked:()=>localStorage.getItem(K)==='1',setLocked(v){localStorage.setItem(K,v?'1':'0');return !!v}}})();
