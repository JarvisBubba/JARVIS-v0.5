/* J.A.R.V.I.S. ADMIN — user helpers */
window.JARVIS=window.JARVIS||{};JARVIS.admin=JARVIS.admin||{};
JARVIS.admin.users={list:()=>{try{return JSON.parse(localStorage.getItem('jarvis-users')||'{}')}catch(_){return {}}}};
