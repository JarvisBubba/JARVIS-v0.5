/* J.A.R.V.I.S. CORE — Brain / intent / reasoning helpers */
window.JARVIS=window.JARVIS||{};
JARVIS.core=JARVIS.core||{};
JARVIS.core.brain=(function(){
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const normalize=t=>String(t||'').replace(/[’]/g,"'").replace(/[−–—]/g,'-').replace(/[×·]/g,'*').replace(/\s+/g,' ').trim();
  function classify(t){
    const q=normalize(t).toLowerCase();
    if(/\b(graph|plot|slope|intercept|quadratic|factor|solve|simplify|equation|inequality|polynomial|function|sequence|radical|log|ln)\b|[x-y-z]\s*[=<>]/.test(q))return 'math';
    if(/\b(atom|cell|force|energy|gravity|chemical|reaction|photosynthesis|dna|ecosystem|planet|motion)\b/.test(q))return 'science';
    if(/\b(essay|thesis|metaphor|simile|grammar|verb|pronoun|theme|tone|paragraph|literary)\b/.test(q))return 'ela';
    if(/\b(history|government|federalism|constitution|war|civilization|geography|economics|democracy|civics)\b/.test(q))return 'history';
    if(/\b(teach me|quiz me|practice|study|homework|assignment|test prep)\b/.test(q))return 'learning';
    return 'general';
  }
  function complexity(t){const q=normalize(t); let s=0; if(q.length>80)s++; if(/[()]/.test(q))s++; if(/[x-z][^=]*[x-z]/i.test(q))s++; if(/[<>]=?|=/.test(q))s++; if(/\^|[²³⁴⁵⁶⁷⁸⁹]/.test(q))s++; return clamp(s,0,5);}
  function responsePolicy(subject){return {subject,steps:true,verify:subject==='math'||subject==='science',concise:false,askWhenAmbiguous:true};}
  return {normalize,classify,complexity,responsePolicy};
})();
