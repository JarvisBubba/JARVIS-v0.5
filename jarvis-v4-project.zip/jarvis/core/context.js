/* J.A.R.V.I.S. CORE — conversation context */
window.JARVIS=window.JARVIS||{};
JARVIS.core=JARVIS.core||{};
JARVIS.core.context=(function(){
  const MAX=12, KEY='jarvis-v4-context';
  const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(_){return []}};
  let history=load();
  function push(role,text,meta={}){history.push({role,text:String(text),meta,ts:Date.now()}); if(history.length>MAX)history=history.slice(-MAX);localStorage.setItem(KEY,JSON.stringify(history));}
  function last(role){for(let i=history.length-1;i>=0;i--)if(!role||history[i].role===role)return history[i];return null}
  function recent(n=6){return history.slice(-n)}
  function clear(){history=[];localStorage.removeItem(KEY)}
  function followupIntent(q){const t=String(q||'').toLowerCase().trim();return /^(repeat|say that again|what did you say|what did i ask|why|how|explain that|make it easier|go back|next step|previous step|check my work|is that right)\b/.test(t)}
  return {push,last,recent,clear,followupIntent};
})();
