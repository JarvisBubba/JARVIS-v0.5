/* J.A.R.V.I.S. CORE — persistent memory */
window.JARVIS=window.JARVIS||{};
JARVIS.core=JARVIS.core||{};
JARVIS.core.memory=(function(){
  const KEY='jarvis-v4-memory';
  const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(_){return {}}};
  const write=m=>localStorage.setItem(KEY,JSON.stringify(m));
  function set(k,v){const m=read();m[String(k).toLowerCase()]=v;write(m);return v}
  function get(k,d=null){const m=read();return Object.prototype.hasOwnProperty.call(m,String(k).toLowerCase())?m[String(k).toLowerCase()]:d}
  function forget(k){const m=read();delete m[String(k).toLowerCase()];write(m)}
  function list(){return read()}
  function rememberFact(text){return set('fact_'+Date.now(),text)}
  return {set,get,forget,list,rememberFact,clear:()=>write({})};
})();
