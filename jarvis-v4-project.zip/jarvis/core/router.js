/* J.A.R.V.I.S. CORE — central router */
window.JARVIS=window.JARVIS||{};JARVIS.core=JARVIS.core||{};
JARVIS.core.router=(function(){
 function route(input){const q=JARVIS.core.brain.normalize(input);const subject=JARVIS.core.brain.classify(q);JARVIS.core.context.push('user',q,{subject});return {subject,kind:JARVIS.math&&JARVIS.math.parser?JARVIS.math.parser.kind(q):'unknown',input:q}}
 function followup(q){const c=JARVIS.core.context;if(!c.followupIntent(q))return null;const last=c.last('assistant');if(!last)return null;const t=String(q).toLowerCase().trim();if(t.startsWith('repeat')||t==='say that again'||t==='what did you say')return last.text;if(t==='why')return 'Because that was the previous step or explanation. Ask me which part you want unpacked.';return last.text}
 return {route,followup};
})();
