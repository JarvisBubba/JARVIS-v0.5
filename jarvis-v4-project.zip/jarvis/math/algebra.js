/* J.A.R.V.I.S. MATH — elementary symbolic transformations */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.algebra=(function(){
 const P=JARVIS.math.parser;
 function distribute(s){const x=P.normalize(s);const m=x.match(/^([+-]?[0-9a-zA-Z]+)\((.+)\)$/i);if(!m)return null;const a=m[1],inside=m[2];const terms=inside.split(/\s*([+-])\s*/);if(!terms.length)return null;let out='',sign='+';for(let i=0;i<terms.length;i++){if(i%2===1){sign=terms[i];continue}if(!terms[i])continue;out+=(out?' ':'')+(sign==='-'?'-':'')+a+'*'+terms[i];}return out.replace(/\*/g,'');}
 function combineSimple(s){let x=P.normalize(s).replace(/\s+/g,'');const parts=x.match(/[+-]?\d*[a-z](?:\^\d+)?/gi)||[];if(parts.length<2)return null;const consts=x.match(/[+-]?\d+(?![a-z])/gi)||[];return {terms:parts,constants:consts};}
 return {normalize:P.normalize,distribute,combineSimple};
})();
