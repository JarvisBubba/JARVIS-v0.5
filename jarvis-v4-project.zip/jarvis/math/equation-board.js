/* J.A.R.V.I.S. MATH — visual equation board facade */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.equationBoard=(function(){
  function steps(input){
    const n=JARVIS.math.parser.normalize(input);
    const out=[{label:'INPUT',equation:n,reason:'Original expression'}];
    const d=JARVIS.math.algebra.distribute(n);
    if(d&&d!==n)out.push({label:'DISTRIBUTE',equation:d.replace(/\*/g,''),reason:'Multiply the outside factor by each term inside the parentheses.'});
    if(/^graph\b/i.test(n)){
      const g=JARVIS.math.graphing.linear(n);if(g){out.push({label:'SLOPE',equation:`m = ${g.m}`,reason:'Read the coefficient of x.'});out.push({label:'INTERCEPT',equation:`b = ${g.b}`,reason:'Read the constant term.'});}
    }
    return out;
  }
  function render(input,target){const el=typeof target==='string'?document.getElementById(target):target;if(!el)return steps(input);const s=steps(input);el.innerHTML='';s.forEach((x,i)=>{const d=document.createElement('div');d.className='jv-step'+(i===0?' active':'');d.dataset.index=i;d.innerHTML=`<b>${x.label}</b><div>${x.equation}</div><small>${x.reason}</small>`;el.appendChild(d)});return s}
  return {steps,render};
})();
