/* J.A.R.V.I.S. MATH — graph model */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.graphing=(function(){
 function linear(s){const x=JARVIS.math.parser.normalize(s).replace(/^graph\s+/i,'').replace(/\s/g,'');let m=x.match(/^y=([+-]?\d*\.?\d*)x([+-]\d*\.?\d+)$/i);if(!m){m=x.match(/^y=([+-]?\d*\.?\d*)$/i);if(m)return {m:0,b:+m[1]};return null}const a=m[1]===''||m[1]==='+'?1:m[1]==='-'?-1:+m[1];return {m:a,b:+m[2],xIntercept:-m[2]/a}}
 function sample(model,from=-5,to=5,n=11){const pts=[];for(let i=0;i<n;i++){const x=from+(to-from)*i/(n-1);pts.push({x,y:model.m*x+model.b})}return pts}
 return {linear,sample};
})();
