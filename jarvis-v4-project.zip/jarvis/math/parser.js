/* J.A.R.V.I.S. MATH — notation parser / normalization */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.parser=(function(){
 const supers={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9'};
 function normalize(s){
  let x=String(s||'').replace(/[’]/g,"'").replace(/[−–—]/g,'-').replace(/[×·]/g,'*');
  x=x.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]/g,c=>' ^'+supers[c]).replace(/\s+/g,' ').trim();
  x=x.replace(/\^\s+(\d+)/g,'^$1');
  x=x.replace(/\b([a-zA-Z])([2-9])\b/g,'$1^$2');
  return x;
 }
 function kind(s){const x=normalize(s);if(/\b(and)\b/i.test(x)&&/=/.test(x))return 'system';if(/[=<>]/.test(x))return 'equation';if(/^\s*graph\b/i.test(x))return 'graph';if(/^[\s\w+\-*/().^]+$/.test(x))return 'expression';return 'unknown'}
 function vars(s){const x=normalize(s).toLowerCase();const set=new Set();for(const m of x.matchAll(/\b[a-z]\b/g))set.add(m[0]);return [...set]}
 return {normalize,kind,vars,supers};
})();
