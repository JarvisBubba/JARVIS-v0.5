/* J.A.R.V.I.S. MATH — polynomial inspection/factoring helpers */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.polynomials=(function(){
 function degree(s){const x=JARVIS.math.parser.normalize(s);let d=0;for(const m of x.matchAll(/\^\s*(\d+)/g))d=Math.max(d,+m[1]);if(d===0&&/\bx\b/i.test(x))d=1;return d}
 function terms(s){const x=JARVIS.math.parser.normalize(s).replace(/\s+/g,'');return x.replace(/-/g,'+-').split('+').filter(Boolean)}
 function leadingCoefficient(s){const ts=terms(s);if(!ts.length)return null;const m=ts[0].match(/^([+-]?\d*\.?\d*)[a-zA-Z]/);if(!m)return null;return m[1]===''||m[1]==='+'?1:m[1]==='-'?-1:+m[1]}
 return {degree,terms,leadingCoefficient};
})();
