/* J.A.R.V.I.S. MATH — quadratic utilities */
window.JARVIS=window.JARVIS||{};JARVIS.math=JARVIS.math||{};
JARVIS.math.quadratics=(function(){
 function parse(s){const x=JARVIS.math.parser.normalize(s).replace(/\s/g,'').replace(/^.*?=/,'').replace(/=0$/,'');const m=x.match(/^([+-]?\d*\.?\d*)x\^2([+-]\d*\.?\d*)x([+-]\d*\.?\d+)$/);if(!m)return null;const a=m[1]===''||m[1]==='+'?1:m[1]==='-'?-1:+m[1],b=m[2]===''||m[2]==='+'?1:m[2]==='-'?-1:+m[2],c=+m[3];return {a,b,c}}
 function solve(s){const p=parse(s);if(!p)return null;const D=p.b*p.b-4*p.a*p.c;const den=2*p.a;if(D<0)return {a:p.a,b:p.b,c:p.c,D,roots:[`(-${p.b} + i√${-D})/${den}`,`(-${p.b} - i√${-D})/${den}`],real:false};const r1=(-p.b+Math.sqrt(D))/den,r2=(-p.b-Math.sqrt(D))/den;return {a:p.a,b:p.b,c:p.c,D,roots:r1===r2?[r1]:[r1,r2],real:true}}
 return {parse,solve};
})();
