/* J.A.R.V.I.S. TOOLS — homework scanner facade */
window.JARVIS=window.JARVIS||{};JARVIS.tools=JARVIS.tools||{};
JARVIS.tools.scanner=(function(){
  function normalizeText(t){return String(t||'').replace(/[−–—]/g,'-').replace(/[×·]/g,'*').replace(/[’]/g,"'").trim()}
  function classify(text){const s=normalizeText(text);return JARVIS.core.brain.classify(s)}
  return {normalizeText,classify};
})();
