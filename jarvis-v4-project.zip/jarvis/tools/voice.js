/* J.A.R.V.I.S. TOOLS — voice facade */
window.JARVIS=window.JARVIS||{};JARVIS.tools=JARVIS.tools||{};
JARVIS.tools.voice={speak:t=>{try{if(window.speak)window.speak(t);else if('speechSynthesis'in window){const u=new SpeechSynthesisUtterance(String(t));speechSynthesis.cancel();speechSynthesis.speak(u)}}catch(_){}}};
