/* J.A.R.V.I.S. TOOLS — XP facade */
window.JARVIS=window.JARVIS||{};JARVIS.tools=JARVIS.tools||{};
JARVIS.tools.xp=(function(){const KEY='jarvis-xp';function read(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(_){return {}}}function get(user){return read()[user||localStorage.getItem('jarvis-session')||'']||0}function add(user,n){const m=read(),k=user||localStorage.getItem('jarvis-session')||'';m[k]=(m[k]||0)+Math.max(0,+n||0);localStorage.setItem(KEY,JSON.stringify(m));return m[k]}return {get,add};})();
